"""BudgetBuddy - a small spending and allowance tracker.

Run it with:  python main.py
"""

import storage
from features import core, reports


def show_menu():
    print()
    print("=== BudgetBuddy ===")
    print("1) Show balance")
    print("2) List transactions")
    print("3) Add a transaction")
    print("4) Filter by category")
    print("5) Show the last transaction")
    print("6) Category breakdown")
    print("7) Spending summary")
    print("8) Account summary")
    print("9) Find big expenses")
    print("10) Show top spending category")
    print("11) Set / check category budgets")
    print("12) Monthly summary")
    print("13) Set / check savings goal")
    print("14) Search transactions")
    print("15) Export transactions to CSV")
    print("0) Quit")


def read_money(prompt, *, allow_zero=False):
    while True:
        raw = input(prompt).strip().replace("$", "")
        try:
            amount = float(raw)
            if amount < 0 or (amount == 0 and not allow_zero):
                print("Enter a positive amount." if not allow_zero else "Enter zero or a positive amount.")
                continue
            return round(amount, 2)
        except ValueError:
            print("Please enter a valid number, such as 12.50.")


def print_budget_status(status):
    remaining = status["remaining"]
    if status["over_budget"]:
        print(f'OVER BUDGET: {status["category"]} spent ${status["spent"]:.2f} / ${status["limit"]:.2f} '
              f'(${abs(remaining):.2f} over).')
    else:
        print(f'{status["category"]}: ${status["spent"]:.2f} / ${status["limit"]:.2f} '
              f'(${remaining:.2f} left).')


def main():
    data = storage.load_data()
    data.setdefault("budgets", {})

    while True:
        show_menu()
        try:
            choice = input("Pick an option: ").strip()
        except EOFError:
            print()
            break

        try:
            if choice == "0":
                storage.save_data(data)
                print("See you next session!")
                break
            elif choice == "1":
                print(f'Balance: ${core.balance(data):.2f}')
            elif choice == "2":
                core.list_transactions(core.get_transactions(data))
            elif choice == "3":
                description = input("Description: ").strip()
                amount = read_money("Amount (enter the number only): ", allow_zero=True)
                while True:
                    direction = input("Is this spending? (y/n): ").strip().lower()
                    if direction in {"y", "n"}:
                        break
                    print("Please enter y for spending or n for income.")
                amount = -abs(amount) if direction == "y" else abs(amount)
                category = input("Category (default: general): ").strip() or "general"
                tx = core.add_transaction(data, description, amount, category)
                storage.save_data(data)
                print(f'Added {tx["description"]} for ${tx["amount"]:.2f}.')
            elif choice == "4":
                category = input("Category: ").strip()
                matches = core.transactions_by_category(core.get_transactions(data), category)
                core.list_transactions(matches)
            elif choice == "5":
                tx = core.last_transaction(core.get_transactions(data))
                if tx:
                    core.list_transactions([tx])
                else:
                    print("No transactions yet.")
            elif choice == "6":
                report = reports.category_report(data)
                if not report:
                    print("No category totals yet.")
                else:
                    for category, total in sorted(report.items()):
                        print(f"{category}: ${total:.2f} net")
            elif choice == "7":
                txns = core.get_transactions(data)
                print(f'Spent ${core.total_spent(txns):.2f} over {len(txns)} transactions '
                      f'(average ${core.average_transaction(txns):.2f}).')
            elif choice == "8":
                print(reports.account_summary(data))
            elif choice == "9":
                threshold = read_money("Show expenses of at least $", allow_zero=False)
                core.list_transactions(core.big_expenses(core.get_transactions(data), threshold))
            elif choice == "10":
                category = core.top_spending_category(core.get_transactions(data))
                print(f"Top spending category: {category}" if category else "No expenses recorded yet.")
            elif choice == "11":
                category = input("Category: ").strip().lower()
                if category not in data.get("budgets", {}):
                    limit = read_money("Set a budget for this category ($): ")
                    core.set_category_budget(data, category, limit)
                    storage.save_data(data)
                    print(f"Budget saved for {category}.")
                print_budget_status(core.budget_status(data, category))
                over = core.over_budget_categories(data)
                if over:
                    print("Categories over budget:")
                    for status in over:
                        print_budget_status(status)
            elif choice == "12":
                summary = reports.monthly_summary(core.get_transactions(data))
                if not summary:
                    print("No dated transactions yet. New transactions are dated automatically.")
                for month, totals in summary.items():
                    print(f'{month}: income ${totals["income"]:.2f} | spent ${totals["spending"]:.2f}')
            elif choice == "13":
                if "savings_goal" not in data:
                    goal = read_money("Savings goal ($): ", allow_zero=True)
                    core.set_savings_goal(data, goal)
                    storage.save_data(data)
                else:
                    print(f'Current savings goal: ${data["savings_goal"]:.2f}')
                    update = input("Change it? (y/n): ").strip().lower()
                    if update == "y":
                        goal = read_money("New savings goal ($): ", allow_zero=True)
                        core.set_savings_goal(data, goal)
                        storage.save_data(data)
                goal = float(data.get("savings_goal", 0))
                print(f'Progress: {core.savings_progress(data):.1f}% '
                      f'(${core.balance(data):.2f} of ${goal:.2f}).')
            elif choice == "14":
                keyword = input("Search description: ").strip()
                core.list_transactions(core.search_transactions(core.get_transactions(data), keyword))
            elif choice == "15":
                from features.exports import export_transactions_csv
                path = input("CSV filename (default: transactions.csv): ").strip() or "transactions.csv"
                export_transactions_csv(core.get_transactions(data), path)
                print(f"Exported {len(core.get_transactions(data))} transactions to {path}.")
            else:
                print("Please pick a number from the menu.")
        except (ValueError, OSError) as error:
            print(f"Could not complete that action: {error}")
        except EOFError:
            print("\nInput ended. See you next session!")
            break


if __name__ == "__main__":
    main()
