# Release Notes

## v1.1 - 2026-11-16
### Added
- Added large-expense alerts, top spending category, and category totals.
- Added category budgets with over-budget warnings.
- Added monthly income/spending summaries and automatic dates for new transactions.
- Added savings-goal progress, transaction search, and CSV export.
- Expanded account and transaction summaries and added automated tests.

## v1.0 - Starter
- Added basic transaction entry, transaction listing, balance, and account summary.
