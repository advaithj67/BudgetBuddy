# BudgetBuddy

BudgetBuddy is a terminal-based allowance and spending tracker for Elite 101.
It stores transactions locally in `data/budgetbuddy.json` and requires no
third-party packages.

## Run it

```bash
python main.py
python -m unittest -v
```

## Features

- Record income and expenses, categorized and date-stamped.
- Check balances, transaction history, category totals, and account summaries.
- Flag large expenses and identify the top spending category.
- Set spending limits by category and see when a limit is exceeded.
- Set a savings goal and view progress (capped at 100%).
- Review monthly income and spending totals.
- Search transactions and export them to CSV.

Monthly summaries skip older transactions that do not have a valid date. New
transactions receive the current date automatically.

## Team

<!-- Add yourself here on your Git lesson: - Your Name (role) -->

- (your squad will add themselves here)

## Project files

| File | What it does |
|---|---|
| `main.py` | Terminal menu |
| `storage.py` | JSON persistence |
| `features/core.py` | Transaction and account logic |
| `features/reports.py` | Summary reports |
| `features/exports.py` | CSV export |
| `tests/` | Automated tests |
| `tickets/` | Original feature roadmap |

Read `CONTRIBUTING.md` for the Definition of Done for pull requests.
