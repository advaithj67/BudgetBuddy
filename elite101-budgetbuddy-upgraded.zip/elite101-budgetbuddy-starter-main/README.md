# BudgetBuddy

A small spending and allowance tracker you run in the terminal. Track income
and expenses, see your balance, and understand where your money goes.

## Run it

```bash
python main.py
```

## Run the tests

```bash
python -m unittest -v
```

No third-party packages are required.

## Features

- Track income and expenses with a category and an automatic date.
- View your balance, transaction history, category totals, and spending summary.
- Find large purchases and your top spending category.
- Set category budgets and get a warning when spending passes a limit.
- Set a savings goal and track progress toward it.
- Review monthly income and spending trends.
- Search transaction descriptions and export transactions to CSV.

**Note:** Monthly reports use transactions with a valid `YYYY-MM-DD` date.
Older records without dates remain in the account and are simply left out of
monthly reports; new transactions receive today's date automatically.

## Project layout

| Path | What it does |
|---|---|
| `main.py` | The terminal menu and user interaction |
| `storage.py` | Loads and saves the JSON data file |
| `features/core.py` | Transactions, balances, budgets, savings goals, and search |
| `features/reports.py` | Account, category, and monthly reports |
| `features/exports.py` | CSV export |
| `data/budgetbuddy.json` | Account settings and transaction history |
| `tests/` | Automated tests |
| `tickets/` | Original feature roadmap |

## Data format

BudgetBuddy stores account data locally in `data/budgetbuddy.json`. Expenses
use negative amounts and income uses positive amounts. Category budgets are
stored in a `budgets` object, and the savings target is stored as
`savings_goal`.

## Team workflow

Read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request. Keep
changes tested and update the release notes when shipping a feature.
