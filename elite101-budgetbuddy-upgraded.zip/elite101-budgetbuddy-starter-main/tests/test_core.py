"""Tests for BudgetBuddy's transaction, budget, goal, and report features."""

import csv
import tempfile
import unittest
from pathlib import Path

from features import core, reports
from features.exports import export_transactions_csv


class TestCore(unittest.TestCase):
    def setUp(self):
        self.data = {
            "account_name": "Test account",
            "starting_balance": 50.0,
            "transactions": [
                {"id": 1, "description": "Bus pass", "amount": -2.5, "category": "transport", "date": "2026-10-02"},
                {"id": 2, "description": "Allowance", "amount": 20.0, "category": "income", "date": "2026-10-03"},
                {"id": 3, "description": "Lunch", "amount": -6.75, "category": "food", "date": "2026-11-04"},
                {"id": 4, "description": "Movie ticket", "amount": -12.0, "category": "fun", "date": "2026-11-05"},
                {"id": 5, "description": "Snack", "amount": -3.25, "category": "food", "date": "2026-11-06"},
            ],
        }

    def test_balance(self):
        self.assertEqual(core.balance(self.data), 45.5)

    def test_add_transaction_gives_a_new_id_and_date(self):
        tx = core.add_transaction(self.data, "New thing", -3.0, "Fun", "2026-11-16")
        self.assertEqual(tx["id"], 6)
        self.assertEqual(tx["category"], "fun")
        self.assertEqual(tx["date"], "2026-11-16")

    def test_empty_last_transaction(self):
        self.assertIsNone(core.last_transaction([]))

    def test_big_expenses_mixed_and_none(self):
        self.assertEqual([t["description"] for t in core.big_expenses(self.data["transactions"], 10)],
                         ["Movie ticket"])
        self.assertEqual(core.big_expenses(self.data["transactions"], 100), [])
        with self.assertRaises(ValueError):
            core.big_expenses(self.data["transactions"], 0)

    def test_top_spending_category(self):
        self.assertEqual(core.top_spending_category(self.data["transactions"]), "fun")
        self.assertIsNone(core.top_spending_category([{"amount": 25, "category": "income"}]))

    def test_category_report(self):
        self.assertEqual(reports.category_report(self.data), {
            "transport": -2.5, "income": 20.0, "food": -10.0, "fun": -12.0
        })
        self.assertEqual(reports.category_report({"transactions": []}), {})

    def test_budgets_under_and_over(self):
        core.set_category_budget(self.data, "food", 15)
        core.set_category_budget(self.data, "fun", 10)
        self.assertFalse(core.budget_status(self.data, "food")["over_budget"])
        self.assertTrue(core.budget_status(self.data, "fun")["over_budget"])
        self.assertEqual([s["category"] for s in core.over_budget_categories(self.data)], ["fun"])
        with self.assertRaises(ValueError):
            core.budget_status(self.data, "transport")

    def test_monthly_summary(self):
        self.assertEqual(reports.monthly_summary(self.data["transactions"]), {
            "2026-10": {"income": 20.0, "spending": 2.5},
            "2026-11": {"income": 0.0, "spending": 22.0},
        })
        self.assertEqual(reports.monthly_summary([{"amount": -3}]), {})

    def test_savings_goal_progress(self):
        core.set_savings_goal(self.data, 100)
        self.assertEqual(core.savings_progress(self.data), 45.5)
        self.assertEqual(core.savings_progress({"starting_balance": 100, "transactions": [], "savings_goal": 100}), 100.0)
        self.assertEqual(core.savings_progress({"starting_balance": 150, "transactions": [], "savings_goal": 100}), 100.0)
        self.assertEqual(core.savings_progress({"starting_balance": 20, "transactions": []}), 0.0)

    def test_search_transactions(self):
        self.assertEqual([t["description"] for t in core.search_transactions(self.data["transactions"], "LUNCH")], ["Lunch"])
        self.assertEqual(core.search_transactions(self.data["transactions"], "not here"), [])

    def test_csv_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "transactions.csv"
            export_transactions_csv(self.data["transactions"], path)
            with path.open(newline="", encoding="utf-8") as file:
                rows = list(csv.DictReader(file))
            self.assertEqual(list(rows[0]), ["id", "description", "amount", "category"])
            self.assertEqual(len(rows), 5)
            self.assertEqual(rows[0]["description"], "Bus pass")


if __name__ == "__main__":
    unittest.main()
