"""Core BudgetBuddy logic: transactions, budgets, goals, and helpers."""

from datetime import date


def get_transactions(data):
    """Return the account's transaction list."""
    return data.get("transactions", [])


def add_transaction(data, description, amount, category="general", transaction_date=None):
    """Add a transaction and return it. Expenses are negative; income is positive."""
    description = str(description).strip()
    category = str(category).strip().lower() or "general"
    if not description:
        raise ValueError("Description cannot be empty.")

    amount = float(amount)
    transactions = data.setdefault("transactions", [])
    new_id = max((t.get("id", 0) for t in transactions), default=0) + 1
    tx_date = transaction_date or date.today().isoformat()
    new_tx = {
        "id": new_id,
        "description": description,
        "amount": round(amount, 2),
        "category": category,
        "date": tx_date,
    }
    transactions.append(new_tx)
    return new_tx


def balance(data):
    """Return the current balance, rounded to cents."""
    return round(float(data.get("starting_balance", 0)) + sum(
        float(t.get("amount", 0)) for t in get_transactions(data)
    ), 2)


def list_transactions(transactions, show=print):
    """Print a readable list of transactions."""
    if not transactions:
        show("No transactions found.")
        return
    for tx in transactions:
        tx_date = " | " + tx["date"] if tx.get("date") else ""
        show(
            f'{tx.get("id", "?")}. {tx.get("description", "(no description)")} '
            f'({float(tx.get("amount", 0)):+.2f}) [{tx.get("category", "general")}]'
            f'{tx_date}'
        )


def transactions_by_category(transactions, category):
    category = str(category).strip().lower()
    return [t for t in transactions if str(t.get("category", "general")).lower() == category]


def count_by_category(transactions):
    counts = {}
    for tx in transactions:
        name = tx.get("category", "general")
        counts[name] = counts.get(name, 0) + 1
    return counts


def last_transaction(transactions):
    """Return the newest-added transaction, or None when there are none."""
    return transactions[-1] if transactions else None


def total_spent(transactions):
    return round(sum(-float(t.get("amount", 0)) for t in transactions
                     if float(t.get("amount", 0)) < 0), 2)


def total_income(transactions):
    return round(sum(float(t.get("amount", 0)) for t in transactions
                     if float(t.get("amount", 0)) > 0), 2)


def average_transaction(transactions):
    if not transactions:
        return 0
    return round(sum(float(t.get("amount", 0)) for t in transactions) / len(transactions), 2)


def big_expenses(transactions, threshold):
    """Return expenses whose absolute value is at least a positive threshold."""
    threshold = float(threshold)
    if threshold <= 0:
        raise ValueError("Threshold must be greater than zero.")
    return [t for t in transactions
            if float(t.get("amount", 0)) < 0 and -float(t["amount"]) >= threshold]


def top_spending_category(transactions):
    """Return the category with the greatest expense total, or None."""
    totals = {}
    for tx in transactions:
        amount = float(tx.get("amount", 0))
        if amount < 0:
            category = tx.get("category", "general")
            totals[category] = totals.get(category, 0) - amount
    if not totals:
        return None
    return max(totals, key=totals.get)


def category_spending(transactions, category):
    """Return total expenses for one category as a positive amount."""
    return total_spent(transactions_by_category(transactions, category))


def set_category_budget(data, category, limit):
    category = str(category).strip().lower()
    limit = float(limit)
    if not category:
        raise ValueError("Category cannot be empty.")
    if limit <= 0:
        raise ValueError("Budget must be greater than zero.")
    data.setdefault("budgets", {})[category] = round(limit, 2)
    return data["budgets"][category]


def budget_status(data, category):
    """Return spend, limit, and over-budget status for a configured category."""
    category = str(category).strip().lower()
    budgets = data.get("budgets", {})
    if category not in budgets:
        raise ValueError(f"No budget is set for '{category}'.")
    spent = category_spending(get_transactions(data), category)
    limit = float(budgets[category])
    return {"category": category, "spent": spent, "limit": limit,
            "remaining": round(limit - spent, 2), "over_budget": spent > limit}


def over_budget_categories(data):
    """Return budget status records for categories that have exceeded their limits."""
    results = []
    for category in data.get("budgets", {}):
        status = budget_status(data, category)
        if status["over_budget"]:
            results.append(status)
    return results


def set_savings_goal(data, amount):
    amount = float(amount)
    if amount < 0:
        raise ValueError("Savings goal cannot be negative.")
    data["savings_goal"] = round(amount, 2)
    return data["savings_goal"]


def savings_progress(data):
    """Return progress toward the savings goal as a percentage from 0 to 100."""
    goal = float(data.get("savings_goal", 0) or 0)
    if goal <= 0:
        return 0.0
    return round(max(0.0, min(100.0, balance(data) / goal * 100)), 2)


def search_transactions(transactions, keyword):
    keyword = str(keyword).strip().casefold()
    if not keyword:
        return []
    return [t for t in transactions
            if keyword in str(t.get("description", "")).casefold()]
