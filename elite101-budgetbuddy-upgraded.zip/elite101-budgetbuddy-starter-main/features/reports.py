"""Reporting helpers for BudgetBuddy."""

from datetime import date


def account_summary(data):
    from features import core

    transactions = core.get_transactions(data)
    return (
        f'{data.get("account_name", "BudgetBuddy")}: '
        f'{len(transactions)} transactions | '
        f'Balance: ${core.balance(data):.2f} | '
        f'Income: ${core.total_income(transactions):.2f} | '
        f'Spent: ${core.total_spent(transactions):.2f}'
    )


def category_report(data):
    """Return net transaction totals by category (income positive, expenses negative)."""
    report = {}
    for tx in data.get("transactions", []):
        category = tx.get("category", "general")
        report[category] = report.get(category, 0.0) + float(tx.get("amount", 0))
    return {category: round(total, 2) for category, total in report.items()}


def monthly_summary(transactions):
    """Group dated transactions into YYYY-MM income and spending totals.

    Older transactions without a valid ISO date are skipped rather than assigned
    a made-up month.
    """
    summary = {}
    for tx in transactions:
        raw_date = tx.get("date")
        if not raw_date:
            continue
        try:
            month = date.fromisoformat(raw_date).strftime("%Y-%m")
            amount = float(tx.get("amount", 0))
        except (TypeError, ValueError):
            continue
        totals = summary.setdefault(month, {"income": 0.0, "spending": 0.0})
        if amount > 0:
            totals["income"] += amount
        elif amount < 0:
            totals["spending"] += -amount
    return {
        month: {key: round(value, 2) for key, value in totals.items()}
        for month, totals in sorted(summary.items())
    }
