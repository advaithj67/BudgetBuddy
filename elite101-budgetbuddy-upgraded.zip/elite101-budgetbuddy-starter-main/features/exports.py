"""Export helpers for BudgetBuddy."""

import csv
from pathlib import Path


CSV_FIELDS = ["id", "description", "amount", "category"]


def export_transactions_csv(transactions, path="transactions.csv"):
    """Write transactions to CSV and return the destination path."""
    destination = Path(path)
    with destination.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for tx in transactions:
            writer.writerow({field: tx.get(field, "") for field in CSV_FIELDS})
    return destination
